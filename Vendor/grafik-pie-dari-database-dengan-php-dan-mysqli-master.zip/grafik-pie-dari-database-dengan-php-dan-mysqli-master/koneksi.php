<?php 
$koneksi = mysqli_connect("localhost","root","","grafik_mahasiswa");
?>